# Full Content Section

This is the extracted content area from the saved MHTML file of https://abigcandy-au.com/en/

## Files

- `index.html` – Real content extracted from site (excluding header/footer)
- `scss/style.scss` – Responsive layout using Flexbox and SCSS variables
- `images/` – Empty (add real images if needed)

## Notes

- Uses Flexbox
- Responsive layout (mobile-friendly)
- Placeholder image styles provided
