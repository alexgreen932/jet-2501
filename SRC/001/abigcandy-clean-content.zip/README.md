
# A Big Candy – Responsive Content Section

Includes:
- Clean `index.html` content
- `_content.scss` for easy theming
- Mobile-first layout using Flexbox

To use:
- Compile `_content.scss` to `style.css`
- Open `index.html` in browser
